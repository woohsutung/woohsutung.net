#ifndef _ETHER_WINDOWS_H_
#define _ETHER_WINDOWS_H_

void enqueue_packet( uint8 *buf, int sz );

#endif // _ETHER_WINDOWS_H_
