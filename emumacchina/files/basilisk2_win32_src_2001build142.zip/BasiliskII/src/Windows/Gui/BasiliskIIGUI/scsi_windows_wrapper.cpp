#include "stdafx.h"
#include "\BasiliskII\src\Windows\scsi_windows.cpp"
