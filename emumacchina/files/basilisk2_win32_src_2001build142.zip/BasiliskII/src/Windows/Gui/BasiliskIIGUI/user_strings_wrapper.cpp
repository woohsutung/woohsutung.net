#include "stdafx.h"
#include "\BasiliskII\src\user_strings.cpp"
