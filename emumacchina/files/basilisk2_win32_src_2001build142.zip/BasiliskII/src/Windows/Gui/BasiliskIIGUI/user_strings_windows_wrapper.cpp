#include "stdafx.h"
#include "\BasiliskII\src\Windows\user_strings_windows.cpp"
