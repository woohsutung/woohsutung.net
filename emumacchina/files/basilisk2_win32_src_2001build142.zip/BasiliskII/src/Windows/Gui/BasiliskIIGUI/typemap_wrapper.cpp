#include "stdafx.h"
#include "\BasiliskII\src\Windows\typemap.cpp"
