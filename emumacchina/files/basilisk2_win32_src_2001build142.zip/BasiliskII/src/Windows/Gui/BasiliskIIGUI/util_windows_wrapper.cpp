#include "stdafx.h"
#include "\BasiliskII\src\Windows\util_windows.cpp"

// Dummy
HWND hMainWnd = 0;
