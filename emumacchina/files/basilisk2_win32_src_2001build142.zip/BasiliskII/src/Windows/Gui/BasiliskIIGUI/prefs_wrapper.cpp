#include "stdafx.h"
#include "\BasiliskII\src\prefs.cpp"
